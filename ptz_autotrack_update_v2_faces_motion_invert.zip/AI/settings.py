from __future__ import annotations

import base64
import json
import os
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import List, Optional, Dict, Tuple

BASE_DIR = Path(__file__).resolve().parent
SETTINGS_FILE = BASE_DIR / "settings.json"

# -----------------------------
# Simple XOR "encryption"
# -----------------------------


def _key() -> bytes:
    # Use a machine-unique-ish key; not crypto, just to avoid plaintext in JSON.
    base = os.environ.get("ESP_CAM_AI_KEY", "esp-cam-ai")
    return base.encode("utf-8")


def encrypt(text: str) -> str:
    if text is None:
        return ""
    k = _key()
    data = text.encode("utf-8")
    out = bytes([b ^ k[i % len(k)] for i, b in enumerate(data)])
    return base64.b64encode(out).decode("ascii")


def decrypt(enc: str) -> Tuple[bool, Optional[str]]:
    try:
        raw = base64.b64decode(enc.encode("ascii"))
        k = _key()
        out = bytes([b ^ k[i % len(k)] for i, b in enumerate(raw)])
        return True, out.decode("utf-8")
    except Exception:
        return False, None


# -----------------------------
# Settings
# -----------------------------


@dataclass
class CameraSettings:
    name: str
    stream_url: str
    user: Optional[str] = None
    password: Optional[str] = None  # plaintext in-memory only; persisted encrypted
    token: Optional[str] = None

    mqtt_publish: bool = True
    alt_streams: List[str] = field(default_factory=list)
    is_onvif: bool = False

    overlay_text_pct: float = 4.0
    view_scale: float = 1.0

    # Motion recording
    record_motion: Optional[bool] = None
    motion_sensitivity: Optional[int] = None

    # Per-camera AI toggles (None=inherit from app defaults)
    ai_enabled: Optional[bool] = None
    ai_yolo: Optional[bool] = None
    ai_faces: Optional[bool] = None
    ai_pets: Optional[bool] = None

    overlay_scale: Optional[float] = None

    # PTZ tweaks
    ptz_home_confirmed: bool = False
    ptz_disable_zoom: bool = False  # force-hide PTZ zoom buttons
    ptz_disable_presets: bool = False  # force-hide PTZ presets button

    # PTZ auto-tracking (moving object tracking). Uses detections to keep a target centered.
    autotrack_enabled: bool = False
    autotrack_source: str = "any"               # any|yolo|faces|pets|motion
    autotrack_classes: str = "person,dog,cat"   # comma-separated class/labels to track

    autotrack_deadzone: float = 0.06            # normalized offset deadzone (0..0.5)
    autotrack_kp_pan: float = 0.70              # proportional gain for pan
    autotrack_kp_tilt: float = 0.70             # proportional gain for tilt
    autotrack_max_vel: float = 0.70             # clamp for PTZ velocity (0..1)
    autotrack_min_vel: float = 0.00             # minimum magnitude when non-zero (deadband bypass)
    autotrack_smooth_alpha: float = 0.45        # EMA smoothing (0..1), higher = snappier
    autotrack_iou_min: float = 0.12             # IOU threshold to keep the same target
    autotrack_lost_ms: int = 1500               # stop if target not seen for this long
    autotrack_manual_hold_ms: int = 1200        # pause auto-track after any manual PTZ input

    # Some cheap heads invert axis conventions; these flip the autotracker output (view space)
    autotrack_invert_pan: bool = False
    autotrack_invert_tilt: bool = False

    # "Motion" (frame-diff) pseudo detection (works even for unclassified movement)
    autotrack_include_motion_in_any: bool = False
    autotrack_motion_threshold: int = 22        # grayscale diff threshold (0..255)
    autotrack_motion_min_area_frac: float = 0.010  # min bbox area as fraction of frame (e.g. 1%)

    autotrack_zoom_enabled: bool = False
    autotrack_zoom_target_frac: float = 0.28    # target bbox area fraction when zoom enabled

    # Orientation
    rotation_deg: int = 0
    flip_horizontal: bool = False
    flip_vertical: bool = False


@dataclass
class AppSettings:
    models_dir: Path = Path("models")
    output_dir: Path = Path("recordings")
    logs_dir: Path = Path("logs")

    detect_interval_ms: int = 500
    use_gpu: bool = False
    thresh_yolo: float = 0.35

    # Recording prebuffer (ms)
    prebuffer_ms: int = 3000

    # Optional URLs for remote models/configs
    yolo_url: Optional[str] = None
    haar_url: Optional[str] = None
    face_model: Optional[Path] = None

    # UI state
    window_geometry: Optional[str] = None
    window_state: Optional[str] = None
    window_geometries: Dict[str, str] = field(default_factory=dict)
    window_states: Dict[str, str] = field(default_factory=dict)

    # Motion recording defaults
    record_motion: bool = False
    motion_sensitivity: int = 25

    # AI defaults
    ai_enabled: bool = True
    ai_yolo: bool = True
    ai_faces: bool = True
    ai_pets: bool = True

    # MQTT
    mqtt_enable: bool = False
    mqtt_host: str = "localhost"
    mqtt_port: int = 1883
    mqtt_base_topic: str = "esp_cam_ai"
    mqtt_discovery_prefix: str = "homeassistant"
    mqtt_discovery_under_base_topic: bool = True
    mqtt_user: Optional[str] = None
    mqtt_password: Optional[str] = None

    cameras: List[CameraSettings] = field(default_factory=list)


def load_settings() -> AppSettings:
    if SETTINGS_FILE.exists():
        with SETTINGS_FILE.open("r", encoding="utf-8") as fp:
            raw = json.load(fp)
        cams: List[CameraSettings] = []
        for c in raw.get("cameras", []):
            # Backward-compatible: support plaintext password or encrypted password_enc
            pwd = c.get("password")
            enc = c.get("password_enc")
            if not pwd and enc:
                ok, dec = decrypt(enc)
                pwd = dec if ok else None

            cams.append(
                CameraSettings(
                    name=c.get("name"),
                    stream_url=c.get("stream_url"),
                    user=c.get("user"),
                    password=pwd,
                    token=c.get("token"),
                    mqtt_publish=bool(c.get("mqtt_publish", True)),
                    alt_streams=c.get("alt_streams", []) or [],
                    is_onvif=bool(
                        c.get("is_onvif", False)
                        or (
                            (c.get("alt_streams", []) or [])
                            and str(c.get("stream_url", "") or "").startswith("rtsp://")
                        )
                    ),
                    overlay_text_pct=float(c.get("overlay_text_pct", 4.0) or 4.0),
                    view_scale=float(c.get("view_scale", 1.0) or 1.0),

                    record_motion=c.get("record_motion", raw.get("record_motion")),
                    motion_sensitivity=c.get("motion_sensitivity", raw.get("motion_sensitivity")),

                    ai_enabled=c.get("ai_enabled"),
                    ai_yolo=c.get("ai_yolo"),
                    ai_faces=c.get("ai_faces"),
                    ai_pets=c.get("ai_pets"),
                    overlay_scale=c.get("overlay_scale"),

                    ptz_home_confirmed=bool(c.get("ptz_home_confirmed", False)),
                    ptz_disable_zoom=bool(c.get("ptz_disable_zoom", False)),
                    ptz_disable_presets=bool(c.get("ptz_disable_presets", False)),

                    autotrack_enabled=bool(c.get("autotrack_enabled", False)),
                    autotrack_source=str(c.get("autotrack_source", "any") or "any"),
                    autotrack_classes=str(c.get("autotrack_classes", "person,dog,cat") or "person,dog,cat"),
                    autotrack_deadzone=float(c.get("autotrack_deadzone", 0.06) or 0.06),
                    autotrack_kp_pan=float(c.get("autotrack_kp_pan", 0.70) or 0.70),
                    autotrack_kp_tilt=float(c.get("autotrack_kp_tilt", 0.70) or 0.70),
                    autotrack_max_vel=float(c.get("autotrack_max_vel", 0.70) or 0.70),
                    autotrack_min_vel=float(c.get("autotrack_min_vel", 0.00) or 0.00),
                    autotrack_smooth_alpha=float(c.get("autotrack_smooth_alpha", 0.45) or 0.45),
                    autotrack_iou_min=float(c.get("autotrack_iou_min", 0.12) or 0.12),
                    autotrack_lost_ms=int(c.get("autotrack_lost_ms", 1500) or 1500),
                    autotrack_manual_hold_ms=int(c.get("autotrack_manual_hold_ms", 1200) or 1200),

                    autotrack_invert_pan=bool(c.get("autotrack_invert_pan", False)),
                    autotrack_invert_tilt=bool(c.get("autotrack_invert_tilt", False)),

                    autotrack_include_motion_in_any=bool(c.get("autotrack_include_motion_in_any", False)),
                    autotrack_motion_threshold=int(c.get("autotrack_motion_threshold", 22) or 22),
                    autotrack_motion_min_area_frac=float(c.get("autotrack_motion_min_area_frac", 0.010) or 0.010),

                    autotrack_zoom_enabled=bool(c.get("autotrack_zoom_enabled", False)),
                    autotrack_zoom_target_frac=float(c.get("autotrack_zoom_target_frac", 0.28) or 0.28),

                    rotation_deg=int(c.get("rotation_deg", 0) or 0),
                    flip_horizontal=bool(c.get("flip_horizontal", False)),
                    flip_vertical=bool(c.get("flip_vertical", False)),
                )
            )

        cfg = AppSettings(
            models_dir=Path(raw.get("models_dir", "models")),
            output_dir=Path(raw.get("output_dir", "recordings")),
            logs_dir=Path(raw.get("logs_dir", "logs")),
            detect_interval_ms=int(raw.get("detect_interval_ms", 500)),
            use_gpu=bool(raw.get("use_gpu", False)),
            thresh_yolo=float(raw.get("thresh_yolo", 0.35)),
            prebuffer_ms=int(raw.get("prebuffer_ms", 3000)),

            yolo_url=raw.get("yolo_url"),
            haar_url=raw.get("haar_url"),
            face_model=raw.get("face_model"),

            window_geometry=raw.get("window_geometry"),
            window_state=raw.get("window_state"),
            window_geometries=raw.get("window_geometries", {}) or {},
            window_states=raw.get("window_states", {}) or {},

            record_motion=bool(raw.get("record_motion", False)),
            motion_sensitivity=int(raw.get("motion_sensitivity", 25)),

            ai_enabled=bool(raw.get("ai_enabled", True)),
            ai_yolo=bool(raw.get("ai_yolo", True)),
            ai_faces=bool(raw.get("ai_faces", True)),
            ai_pets=bool(raw.get("ai_pets", True)),

            mqtt_enable=bool(raw.get("mqtt_enable", False)),
            mqtt_host=str(raw.get("mqtt_host", "localhost") or "localhost"),
            mqtt_port=int(raw.get("mqtt_port", 1883) or 1883),
            mqtt_base_topic=str(raw.get("mqtt_base_topic", "esp_cam_ai") or "esp_cam_ai"),
            mqtt_discovery_prefix=str(raw.get("mqtt_discovery_prefix", "homeassistant") or "homeassistant"),
            mqtt_discovery_under_base_topic=bool(raw.get("mqtt_discovery_under_base_topic", True)),
            mqtt_user=raw.get("mqtt_user"),
            mqtt_password=None,
            cameras=cams,
        )

        # Backward-compatible: support plaintext mqtt_password or encrypted mqtt_password_enc
        mp = raw.get("mqtt_password")
        menc = raw.get("mqtt_password_enc")
        if not mp and menc:
            ok, dec = decrypt(menc)
            mp = dec if ok else None
        cfg.mqtt_password = mp
        return cfg

    return AppSettings()


def save_settings(cfg: AppSettings):
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    data = {
        # store as relative-to-base where possible for portability
        "models_dir": str(
            Path(cfg.models_dir).resolve().relative_to(BASE_DIR)
            if str(Path(cfg.models_dir).resolve()).startswith(str(BASE_DIR))
            else str(cfg.models_dir)
        ),
        "output_dir": str(
            Path(cfg.output_dir).resolve().relative_to(BASE_DIR)
            if str(Path(cfg.output_dir).resolve()).startswith(str(BASE_DIR))
            else str(cfg.output_dir)
        ),
        "logs_dir": str(
            Path(cfg.logs_dir).resolve().relative_to(BASE_DIR)
            if str(Path(cfg.logs_dir).resolve()).startswith(str(BASE_DIR))
            else str(cfg.logs_dir)
        ),

        "detect_interval_ms": cfg.detect_interval_ms,
        "use_gpu": cfg.use_gpu,
        "thresh_yolo": cfg.thresh_yolo,
        "prebuffer_ms": cfg.prebuffer_ms,

        "yolo_url": cfg.yolo_url,
        "haar_url": cfg.haar_url,
        "face_model": str(cfg.face_model) if cfg.face_model else None,

        "window_geometry": cfg.window_geometry,
        "window_state": cfg.window_state,
        "window_geometries": cfg.window_geometries,
        "window_states": cfg.window_states,

        "record_motion": cfg.record_motion,
        "motion_sensitivity": cfg.motion_sensitivity,

        "ai_enabled": cfg.ai_enabled,
        "ai_yolo": cfg.ai_yolo,
        "ai_faces": cfg.ai_faces,
        "ai_pets": cfg.ai_pets,

        "mqtt_enable": cfg.mqtt_enable,
        "mqtt_host": cfg.mqtt_host,
        "mqtt_port": cfg.mqtt_port,
        "mqtt_base_topic": cfg.mqtt_base_topic,
        "mqtt_discovery_prefix": cfg.mqtt_discovery_prefix,
        "mqtt_discovery_under_base_topic": cfg.mqtt_discovery_under_base_topic,
        "mqtt_user": cfg.mqtt_user,
        "mqtt_password_enc": encrypt(cfg.mqtt_password) if cfg.mqtt_password else None,

        "cameras": [],
    }

    # Write cameras with encrypted password; avoid persisting plaintext.
    for c in cfg.cameras:
        entry = asdict(c)
        pwd = entry.pop("password", None)
        entry["password_enc"] = encrypt(pwd) if pwd else None
        data["cameras"].append(entry)

    with SETTINGS_FILE.open("w", encoding="utf-8") as fp:
        json.dump(data, fp, indent=2)
