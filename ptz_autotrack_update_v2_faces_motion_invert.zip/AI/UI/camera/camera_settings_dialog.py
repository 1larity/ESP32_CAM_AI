from __future__ import annotations

from PySide6 import QtCore, QtWidgets

from ha_discovery import publish_discovery


class CameraSettingsDialog(QtWidgets.QDialog):
    """
    Per-camera settings (motion recording, LED, overlays, PTZ auto-track).
    """

    def __init__(self, cam_cfg, app_defaults, widget, parent=None):
        super().__init__(parent)
        self.cam_cfg = cam_cfg
        self.app_defaults = app_defaults
        self.widget = widget

        self.setWindowTitle(f"Camera Settings - {cam_cfg.name}")
        self.setModal(True)

        layout = QtWidgets.QFormLayout(self)

        # Camera name
        self.le_name = QtWidgets.QLineEdit(cam_cfg.name)
        layout.addRow("Name", self.le_name)

        # Stream selector
        self.cb_stream = QtWidgets.QComboBox()
        self._custom_stream_url = None
        streams = [cam_cfg.stream_url] + list(getattr(cam_cfg, "alt_streams", []) or [])
        seen = set()
        for s in streams:
            if not s or s in seen:
                continue
            seen.add(s)
            self.cb_stream.addItem(s, userData=s)
        self.cb_stream.addItem("Custom...", userData="__custom__")
        layout.addRow("Stream", self.cb_stream)

        # Motion recording
        self.cb_motion = QtWidgets.QCheckBox("Record on motion")
        self.cb_motion.setChecked(bool(getattr(cam_cfg, "record_motion", app_defaults.record_motion)))
        layout.addRow(self.cb_motion)

        self.s_motion = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        self.s_motion.setMinimum(1)
        self.s_motion.setMaximum(100)
        self.s_motion.setValue(int(getattr(cam_cfg, "motion_sensitivity", app_defaults.motion_sensitivity)))
        layout.addRow("Motion sensitivity", self._add_slider(self.s_motion))

        # MQTT
        self.cb_mqtt = QtWidgets.QCheckBox("Publish MQTT discovery and state")
        self.cb_mqtt.setChecked(bool(getattr(cam_cfg, "mqtt_publish", True)))
        layout.addRow(self.cb_mqtt)

        # AI + overlays
        self.cb_ai_enabled = QtWidgets.QCheckBox("Enable AI (per-camera override)")
        self.cb_ai_enabled.setChecked(
            bool(getattr(cam_cfg, "ai_enabled", None) if getattr(cam_cfg, "ai_enabled", None) is not None else app_defaults.ai_enabled)
        )
        layout.addRow(self.cb_ai_enabled)

        self.cb_ai_yolo = QtWidgets.QCheckBox("YOLO")
        self.cb_ai_yolo.setChecked(bool(getattr(widget._overlays, "yolo", True)))
        layout.addRow(self.cb_ai_yolo)

        self.cb_ai_faces = QtWidgets.QCheckBox("Faces")
        self.cb_ai_faces.setChecked(bool(getattr(widget._overlays, "faces", True)))
        layout.addRow(self.cb_ai_faces)

        self.cb_ai_pets = QtWidgets.QCheckBox("Pets")
        self.cb_ai_pets.setChecked(bool(getattr(widget._overlays, "pets", True)))
        layout.addRow(self.cb_ai_pets)

        # Orientation controls
        self.cb_rotation = QtWidgets.QComboBox()
        self.cb_rotation.addItems(["0°", "90°", "180°", "270°"])
        rot = int(getattr(cam_cfg, "rotation_deg", 0) or 0)
        if rot in (0, 90, 180, 270):
            self.cb_rotation.setCurrentIndex((0, 90, 180, 270).index(rot))
        self.cb_flip_h = QtWidgets.QCheckBox("Flip horizontally (mirror)")
        self.cb_flip_h.setChecked(bool(getattr(cam_cfg, "flip_horizontal", False)))
        self.cb_flip_v = QtWidgets.QCheckBox("Flip vertically")
        self.cb_flip_v.setChecked(bool(getattr(cam_cfg, "flip_vertical", False)))

        layout.addRow("Rotation", self.cb_rotation)
        layout.addRow(self.cb_flip_h)
        layout.addRow(self.cb_flip_v)

        # PTZ visibility tweaks
        self.cb_ptz_hide_zoom = QtWidgets.QCheckBox("Hide PTZ zoom buttons")
        self.cb_ptz_hide_zoom.setChecked(bool(getattr(cam_cfg, "ptz_disable_zoom", False)))
        self.cb_ptz_hide_presets = QtWidgets.QCheckBox("Hide PTZ presets button")
        self.cb_ptz_hide_presets.setChecked(bool(getattr(cam_cfg, "ptz_disable_presets", False)))
        layout.addRow(self.cb_ptz_hide_zoom)
        layout.addRow(self.cb_ptz_hide_presets)

        # Auto-track (PTZ moving object tracking)
        self.cb_autotrack = QtWidgets.QCheckBox("Enable auto-track (PTZ)")
        self.cb_autotrack.setChecked(bool(getattr(cam_cfg, "autotrack_enabled", False)))
        layout.addRow(self.cb_autotrack)

        self.cb_autotrack_source = QtWidgets.QComboBox()
        self.cb_autotrack_source.addItems(["any", "yolo", "faces", "pets", "motion"])
        _src = str(getattr(cam_cfg, "autotrack_source", "any") or "any").lower().strip()
        if _src in ("any", "yolo", "faces", "pets", "motion"):
            self.cb_autotrack_source.setCurrentText(_src)
        layout.addRow("Auto-track source", self.cb_autotrack_source)

        self.le_autotrack_classes = QtWidgets.QLineEdit(str(getattr(cam_cfg, "autotrack_classes", "person,dog,cat") or ""))
        self.le_autotrack_classes.setPlaceholderText("e.g. person,face,dog,cat   (blank = no filter)")
        layout.addRow("Track classes", self.le_autotrack_classes)

        self.cb_autotrack_motion_in_any = QtWidgets.QCheckBox("Include motion tracking when source=any")
        self.cb_autotrack_motion_in_any.setChecked(bool(getattr(cam_cfg, "autotrack_include_motion_in_any", False)))
        layout.addRow(self.cb_autotrack_motion_in_any)

        self.sp_autotrack_deadzone = QtWidgets.QDoubleSpinBox()
        self.sp_autotrack_deadzone.setRange(0.00, 0.50)
        self.sp_autotrack_deadzone.setSingleStep(0.01)
        self.sp_autotrack_deadzone.setDecimals(2)
        self.sp_autotrack_deadzone.setValue(float(getattr(cam_cfg, "autotrack_deadzone", 0.06) or 0.06))
        layout.addRow("Deadzone (0..0.5)", self.sp_autotrack_deadzone)

        self.sp_autotrack_kp = QtWidgets.QDoubleSpinBox()
        self.sp_autotrack_kp.setRange(0.05, 2.00)
        self.sp_autotrack_kp.setSingleStep(0.05)
        self.sp_autotrack_kp.setDecimals(2)
        self.sp_autotrack_kp.setValue(float(getattr(cam_cfg, "autotrack_kp_pan", 0.70) or 0.70))
        layout.addRow("Gain (KP)", self.sp_autotrack_kp)

        self.sp_autotrack_max_vel = QtWidgets.QDoubleSpinBox()
        self.sp_autotrack_max_vel.setRange(0.10, 1.00)
        self.sp_autotrack_max_vel.setSingleStep(0.05)
        self.sp_autotrack_max_vel.setDecimals(2)
        self.sp_autotrack_max_vel.setValue(float(getattr(cam_cfg, "autotrack_max_vel", 0.70) or 0.70))
        layout.addRow("Max speed", self.sp_autotrack_max_vel)

        self.sp_autotrack_min_vel = QtWidgets.QDoubleSpinBox()
        self.sp_autotrack_min_vel.setRange(0.00, 1.00)
        self.sp_autotrack_min_vel.setSingleStep(0.05)
        self.sp_autotrack_min_vel.setDecimals(2)
        self.sp_autotrack_min_vel.setValue(float(getattr(cam_cfg, "autotrack_min_vel", 0.00) or 0.00))
        layout.addRow("Min speed (deadband)", self.sp_autotrack_min_vel)

        self.cb_autotrack_inv_pan = QtWidgets.QCheckBox("Invert pan for auto-track")
        self.cb_autotrack_inv_pan.setChecked(bool(getattr(cam_cfg, "autotrack_invert_pan", False)))
        layout.addRow(self.cb_autotrack_inv_pan)

        self.cb_autotrack_inv_tilt = QtWidgets.QCheckBox("Invert tilt for auto-track")
        self.cb_autotrack_inv_tilt.setChecked(bool(getattr(cam_cfg, "autotrack_invert_tilt", False)))
        layout.addRow(self.cb_autotrack_inv_tilt)

        # Motion pseudo-detection tuning
        self.sp_motion_thr = QtWidgets.QSpinBox()
        self.sp_motion_thr.setRange(1, 255)
        self.sp_motion_thr.setSingleStep(1)
        self.sp_motion_thr.setValue(int(getattr(cam_cfg, "autotrack_motion_threshold", 22) or 22))
        layout.addRow("Motion diff threshold", self.sp_motion_thr)

        self.sp_motion_min_area = QtWidgets.QDoubleSpinBox()
        self.sp_motion_min_area.setRange(0.000, 0.250)
        self.sp_motion_min_area.setSingleStep(0.005)
        self.sp_motion_min_area.setDecimals(3)
        self.sp_motion_min_area.setValue(float(getattr(cam_cfg, "autotrack_motion_min_area_frac", 0.010) or 0.010))
        layout.addRow("Motion min area (fraction)", self.sp_motion_min_area)

        self.sp_autotrack_hold = QtWidgets.QSpinBox()
        self.sp_autotrack_hold.setRange(0, 10000)
        self.sp_autotrack_hold.setSingleStep(100)
        self.sp_autotrack_hold.setValue(int(getattr(cam_cfg, "autotrack_manual_hold_ms", 1200) or 1200))
        layout.addRow("Manual hold (ms)", self.sp_autotrack_hold)

        self.cb_autotrack_zoom = QtWidgets.QCheckBox("Enable zoom while tracking")
        self.cb_autotrack_zoom.setChecked(bool(getattr(cam_cfg, "autotrack_zoom_enabled", False)))
        layout.addRow(self.cb_autotrack_zoom)

        # Buttons
        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok
            | QtWidgets.QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

        # Stream change handling
        self.cb_stream.currentIndexChanged.connect(self._on_stream_changed)

    def _on_stream_changed(self, idx: int) -> None:
        data = self.cb_stream.itemData(idx)
        if data == "__custom__":
            self._prompt_custom_stream()

    def _add_slider(self, slider: QtWidgets.QSlider) -> QtWidgets.QWidget:
        c = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(c)
        h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(slider)
        lbl = QtWidgets.QLabel(str(int(slider.value())))
        h.addWidget(lbl)
        slider.valueChanged.connect(lambda v: lbl.setText(str(int(v))))
        return c

    def _prompt_custom_stream(self) -> None:
        txt, ok = QtWidgets.QInputDialog.getText(self, "Stream URL", "Enter stream URL:", text=self.cam_cfg.stream_url)
        if ok and txt:
            url = txt.strip()
            if url:
                self._custom_stream_url = url
                if hasattr(self, "cb_stream"):
                    idx = self.cb_stream.findData(url)
                    if idx == -1:
                        self.cb_stream.addItem(f"Custom: {url}", userData=url)
                        idx = self.cb_stream.count() - 1
                    self.cb_stream.setCurrentIndex(idx)

    def apply(self):
        old_name = str(getattr(self.cam_cfg, "name", "") or "")
        new_name = str(self.le_name.text() or "").strip() or old_name
        renamed = (new_name != old_name)

        self.cam_cfg.name = new_name

        # Stream URL
        idx = self.cb_stream.currentIndex()
        data = self.cb_stream.itemData(idx)
        if data and data != "__custom__":
            self.cam_cfg.stream_url = str(data)
        elif self._custom_stream_url:
            self.cam_cfg.stream_url = str(self._custom_stream_url)

        # AI + overlays
        self.cam_cfg.ai_enabled = bool(self.cb_ai_enabled.isChecked())
        try:
            self.widget._apply_ai_enabled(self.cam_cfg.ai_enabled)
        except Exception:
            pass

        try:
            self.widget._overlays.yolo = bool(self.cb_ai_yolo.isChecked())
            self.widget._overlays.faces = bool(self.cb_ai_faces.isChecked())
            self.widget._overlays.pets = bool(self.cb_ai_pets.isChecked())
            self.widget._sync_overlay_master()
        except Exception:
            pass

        # Orientation
        rot_text = self.cb_rotation.currentText().replace("°", "")
        try:
            self.cam_cfg.rotation_deg = int(rot_text)
        except Exception:
            self.cam_cfg.rotation_deg = 0
        self.cam_cfg.flip_horizontal = bool(self.cb_flip_h.isChecked())
        self.cam_cfg.flip_vertical = bool(self.cb_flip_v.isChecked())
        try:
            self.widget._apply_orientation_settings()
        except Exception:
            pass

        # Motion recording settings
        self.cam_cfg.record_motion = self.cb_motion.isChecked()
        self.cam_cfg.motion_sensitivity = int(self.s_motion.value())

        # MQTT
        mqtt_on = bool(self.cb_mqtt.isChecked())
        if hasattr(self.widget, "_apply_mqtt_publish"):
            try:
                self.widget._apply_mqtt_publish(mqtt_on)
            except Exception:
                pass
        else:
            self.cam_cfg.mqtt_publish = mqtt_on

        if renamed and mqtt_on:
            try:
                publish_discovery(self.widget.app_cfg, self.cam_cfg)
            except Exception:
                pass

        # PTZ visibility options
        hide_zoom = bool(self.cb_ptz_hide_zoom.isChecked())
        hide_presets = bool(self.cb_ptz_hide_presets.isChecked())
        self.cam_cfg.ptz_disable_zoom = hide_zoom
        self.cam_cfg.ptz_disable_presets = hide_presets
        if hasattr(self.widget, "_ptz_force_controls_visibility"):
            try:
                self.widget._ptz_force_controls_visibility()
            except Exception:
                pass

        # Auto-track (PTZ)
        self.cam_cfg.autotrack_enabled = bool(self.cb_autotrack.isChecked())
        self.cam_cfg.autotrack_source = str(self.cb_autotrack_source.currentText()).strip().lower()
        self.cam_cfg.autotrack_classes = str(self.le_autotrack_classes.text() or "").strip()

        dz = float(self.sp_autotrack_deadzone.value())
        kp = float(self.sp_autotrack_kp.value())
        self.cam_cfg.autotrack_deadzone = dz
        self.cam_cfg.autotrack_kp_pan = kp
        self.cam_cfg.autotrack_kp_tilt = kp
        self.cam_cfg.autotrack_max_vel = float(self.sp_autotrack_max_vel.value())
        self.cam_cfg.autotrack_min_vel = float(self.sp_autotrack_min_vel.value())
        self.cam_cfg.autotrack_manual_hold_ms = int(self.sp_autotrack_hold.value())

        self.cam_cfg.autotrack_invert_pan = bool(self.cb_autotrack_inv_pan.isChecked())
        self.cam_cfg.autotrack_invert_tilt = bool(self.cb_autotrack_inv_tilt.isChecked())

        self.cam_cfg.autotrack_include_motion_in_any = bool(self.cb_autotrack_motion_in_any.isChecked())
        self.cam_cfg.autotrack_motion_threshold = int(self.sp_motion_thr.value())
        self.cam_cfg.autotrack_motion_min_area_frac = float(self.sp_motion_min_area.value())

        self.cam_cfg.autotrack_zoom_enabled = bool(self.cb_autotrack_zoom.isChecked())

        # Sync quick toggle in the View menu (if present).
        try:
            if hasattr(self.widget, "act_autotrack"):
                self.widget.act_autotrack.setChecked(bool(self.cam_cfg.autotrack_enabled))
        except Exception:
            pass
