from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional, Tuple

import cv2
import numpy as np

from detectors import DetectionPacket
from utils import monotonic_ms

from .box_tracker import SingleTrack

XYXY = Tuple[int, int, int, int]


def _clamp(v: float, lo: float, hi: float) -> float:
    return float(max(lo, min(hi, v)))


def _center(bb: XYXY) -> Tuple[float, float]:
    x1, y1, x2, y2 = bb
    return (0.5 * (x1 + x2), 0.5 * (y1 + y2))


def _area(bb: XYXY) -> float:
    x1, y1, x2, y2 = bb
    return float(max(0, x2 - x1) * max(0, y2 - y1))


@dataclass
class _Cfg:
    enabled: bool
    source: str
    classes: List[str]
    deadzone: float
    kp_pan: float
    kp_tilt: float
    max_vel: float
    min_vel: float
    smooth_alpha: float
    iou_min: float
    lost_ms: int
    manual_hold_ms: int
    zoom_enabled: bool
    zoom_target_frac: float


class PtzAutoTracker:
    """PTZ auto-track controller.

    Consumes DetectionPacket boxes and drives widget PTZ velocity to keep a
    selected target centered. The CameraWidget already maps pan/tilt to match
    display orientation; therefore this controller outputs screen-style:
      - pan > 0 = move right
      - tilt > 0 = move up
    """

    def __init__(self, widget):
        self.w = widget
        self.track = SingleTrack()
        self._pan = 0.0
        self._tilt = 0.0
        self._zoom = 0.0
        self._active = False

        # "Track anything": simple frame-diff motion bbox when source=motion.
        self._motion_prev_gray: Optional[np.ndarray] = None

    # -------------------------
    # Public API
    # -------------------------

    def status_text(self) -> str:
        if not self._cfg().enabled:
            return ""
        if not bool(getattr(self.w, "_ptz_available", False)):
            return "AT:off"
        if self._active and self.track.bbox is not None:
            lbl = (self.track.label or "").strip()
            return f"AT:{lbl or 'target'}"
        return "AT:on"

    def on_packet(self, pkt: DetectionPacket) -> None:
        cfg = self._cfg()

        # If disabled, ensure we are stopped.
        if not cfg.enabled:
            self._safe_stop()
            return

        if not bool(getattr(self.w, "_ptz_available", False)):
            self._safe_stop()
            return

        if cfg.source != "motion" and not bool(getattr(self.w, "_ai_enabled", False)):
            # Detection-driven sources require AI to be enabled.
            self._safe_stop()
            return

        # Pause after manual PTZ input.
        now = monotonic_ms()
        if now < int(getattr(self.w, "_autotrack_manual_until_ms", 0) or 0):
            self._safe_stop()
            return

        # Update / select target
        dets = list(self._candidates(pkt, cfg))
        ts_ms = int(getattr(pkt, "ts_ms", 0) or 0)

        picked = self.track.update(
            dets,
            ts_ms=ts_ms,
            iou_min=cfg.iou_min,
            prefer_labels=self._prefer_labels(cfg),
        )

        if picked is None:
            # Lost target?
            if self.track.last_seen_ts_ms and (ts_ms - self.track.last_seen_ts_ms) > int(cfg.lost_ms):
                self.track.clear()
                self._safe_stop()
            return

        lbl, sc, bb = picked

        # Compute normalized offsets from center (-1..+1)
        w, h = pkt.size
        cx, cy = _center(bb)
        ox = (cx - (w * 0.5)) / (w * 0.5) if w > 0 else 0.0
        oy = (cy - (h * 0.5)) / (h * 0.5) if h > 0 else 0.0

        dz = float(cfg.deadzone)
        if abs(ox) < dz:
            ox = 0.0
        if abs(oy) < dz:
            oy = 0.0

        # Proportional controller:
        # - pan follows ox (right is +)
        # - tilt is inverted because image y-down, command wants y-up
        pan = _clamp(cfg.kp_pan * ox, -cfg.max_vel, cfg.max_vel)
        tilt = _clamp(-cfg.kp_tilt * oy, -cfg.max_vel, cfg.max_vel)

        zoom = 0.0
        if cfg.zoom_enabled and bool(getattr(self.w, "_ptz_has_zoom", False)):
            frac = _area(bb) / float(max(1, w * h))
            target = float(cfg.zoom_target_frac)
            # Simple bang-bang with proportional-ish scaling
            err = _clamp((target - frac) / max(1e-6, target), -1.0, 1.0)
            zoom = _clamp(0.5 * err, -cfg.max_vel, cfg.max_vel)

        # Smooth output to avoid jitter.
        a = _clamp(cfg.smooth_alpha, 0.0, 1.0)
        self._pan = (a * pan) + ((1.0 - a) * self._pan)
        self._tilt = (a * tilt) + ((1.0 - a) * self._tilt)
        self._zoom = (a * zoom) + ((1.0 - a) * self._zoom)

        # Enforce a minimum movement magnitude for "dumb" PTZ heads that ignore
        # small velocities (they often have a deadband and only respond above a threshold).
        min_v = float(cfg.min_vel)
        if min_v > 0.0:
            if self._pan != 0.0:
                self._pan = _clamp((1.0 if self._pan > 0 else -1.0) * max(abs(self._pan), min_v), -cfg.max_vel, cfg.max_vel)
            if self._tilt != 0.0:
                self._tilt = _clamp((1.0 if self._tilt > 0 else -1.0) * max(abs(self._tilt), min_v), -cfg.max_vel, cfg.max_vel)
            if self._zoom != 0.0:
                self._zoom = _clamp((1.0 if self._zoom > 0 else -1.0) * max(abs(self._zoom), min_v), -cfg.max_vel, cfg.max_vel)

        # If everything is zero, stop.
        if self._pan == 0.0 and self._tilt == 0.0 and self._zoom == 0.0:
            self._safe_stop()
            return

        self._active = True
        self._send_velocity(self._pan, self._tilt, self._zoom)

    # -------------------------
    # Internals
    # -------------------------

    def _cfg(self) -> _Cfg:
        cam = getattr(self.w, "cam_cfg", None)

        def _get(name: str, default):
            try:
                return getattr(cam, name)
            except Exception:
                return default

        enabled = bool(_get("autotrack_enabled", False))
        source = str(_get("autotrack_source", "any") or "any").strip().lower()
        classes = str(_get("autotrack_classes", "person,dog,cat") or "person,dog,cat")
        cls_list = [c.strip().lower() for c in classes.split(",") if c.strip()]
        return _Cfg(
            enabled=enabled,
            source=source if source in ("any", "yolo", "faces", "pets", "motion") else "any",
            classes=cls_list,
            deadzone=float(_get("autotrack_deadzone", 0.06) or 0.06),
            kp_pan=float(_get("autotrack_kp_pan", 0.70) or 0.70),
            kp_tilt=float(_get("autotrack_kp_tilt", 0.70) or 0.70),
            max_vel=_clamp(float(_get("autotrack_max_vel", 0.70) or 0.70), 0.10, 1.00),
            min_vel=_clamp(float(_get("autotrack_min_vel", 0.00) or 0.00), 0.0, 1.00),
            smooth_alpha=_clamp(float(_get("autotrack_smooth_alpha", 0.45) or 0.45), 0.0, 1.0),
            iou_min=_clamp(float(_get("autotrack_iou_min", 0.12) or 0.12), 0.0, 1.0),
            lost_ms=int(_get("autotrack_lost_ms", 1500) or 1500),
            manual_hold_ms=int(_get("autotrack_manual_hold_ms", 1200) or 1200),
            zoom_enabled=bool(_get("autotrack_zoom_enabled", False)),
            zoom_target_frac=_clamp(float(_get("autotrack_zoom_target_frac", 0.28) or 0.28), 0.02, 0.90),
        )

    def _prefer_labels(self, cfg: _Cfg) -> Optional[List[str]]:
        # If user specified classes, we keep that order as preference.
        return cfg.classes or None


    def _motion_candidate(self, frame_bgr, w: int, h: int, sensitivity: int) -> Optional[Tuple[str, float, XYXY]]:
        """Return a single motion bbox (largest moving blob) using frame differencing.

        This is intentionally simple and robust for cheap cameras where classification is unreliable.
        It works on the oriented display frame (self.w._last_bgr).
        """
        try:
            # downscale for speed and to reduce noise
            small_w = 160
            small_h = max(90, int(small_w * (h / max(1, w))))
            small = cv2.resize(frame_bgr, (small_w, small_h))
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (5, 5), 0)
        except Exception:
            return None

        if self._motion_prev_gray is None or self._motion_prev_gray.shape != gray.shape:
            self._motion_prev_gray = gray
            return None

        diff = cv2.absdiff(self._motion_prev_gray, gray)
        self._motion_prev_gray = gray

        # Sensitivity (1..100): higher -> lower threshold.
        sensitivity = max(1, min(100, int(sensitivity)))
        thr = int(max(6, min(60, 45 - (sensitivity * 0.35))))  # ~36 @25, ~17 @80
        _, mask = cv2.threshold(diff, thr, 255, cv2.THRESH_BINARY)
        mask = cv2.dilate(mask, None, iterations=2)

        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            return None

        best = None
        best_area = 0.0
        for c in cnts:
            x, y, ww, hh = cv2.boundingRect(c)
            area = float(ww * hh)
            if area > best_area:
                best_area = area
                best = (x, y, x + ww, y + hh)

        if best is None:
            return None

        # Filter tiny boxes
        frac = best_area / float(max(1, small_w * small_h))
        if frac < 0.02:
            return None

        # Scale bbox back to full-res coordinates
        sx = w / float(small_w)
        sy = h / float(small_h)
        x1, y1, x2, y2 = best
        bb = (int(x1 * sx), int(y1 * sy), int(x2 * sx), int(y2 * sy))

        # Score: fraction of active pixels (rough)
        score = float((mask > 0).mean())
        return ("motion", score, bb)


    def _candidates(self, pkt: DetectionPacket, cfg: _Cfg) -> Iterable[Tuple[str, float, XYXY]]:
        # "Track anything" mode
        if cfg.source == "motion":
            frame = getattr(self.w, "_last_bgr", None)
            if frame is None:
                return
            try:
                w, h = pkt.size
            except Exception:
                # fallback to frame size
                h, w = frame.shape[:2]
            # Reuse motion_sensitivity if available (consistent with motion recording UI)
            sens = int(getattr(getattr(self.w, "cam_cfg", None), "motion_sensitivity", 25) or 25)
            mc = self._motion_candidate(frame, w=w, h=h, sensitivity=sens)
            if mc is not None:
                yield mc
            return

        boxes = []
        if cfg.source in ("any", "yolo") and getattr(pkt, "yolo", None):
            boxes.extend(getattr(pkt, "yolo", []) or [])
        if cfg.source in ("any", "faces") and getattr(pkt, "faces", None):
            boxes.extend(getattr(pkt, "faces", []) or [])
        if cfg.source in ("any", "pets") and getattr(pkt, "pets", None):
            boxes.extend(getattr(pkt, "pets", []) or [])

        for b in boxes:
            try:
                lbl = str(getattr(b, "cls", "") or "").strip()
                sc = float(getattr(b, "score", 0.0) or 0.0)
                bb = getattr(b, "xyxy", None)
                if not bb or len(bb) != 4:
                    continue
                xyxy = (int(bb[0]), int(bb[1]), int(bb[2]), int(bb[3]))

                # Face tracking: accept all faces when source=faces (ignore class filter).
                if cfg.source == "faces":
                    yield ("face" if not lbl else lbl, sc, xyxy)
                    continue

                # Normal filtering for yolo/pets/any
                if cfg.classes:
                    if lbl.strip().lower() not in cfg.classes:
                        continue
                yield (lbl, sc, xyxy)
            except Exception:
                continue


    def _safe_stop(self) -> None:
        if self._active:
            self._active = False

        # "Track anything": simple frame-diff motion bbox when source=motion.
        self._motion_prev_gray: Optional[np.ndarray] = None
            self._pan = self._tilt = self._zoom = 0.0
            self._send_velocity(0.0, 0.0, 0.0)

    def _send_velocity(self, pan: float, tilt: float, zoom: float) -> None:
        # Mark as driving so the CameraWidget wrapper doesn't treat it as manual control.
        try:
            setattr(self.w, "_autotrack_driving", True)
            self.w._ptz_set_velocity(float(pan), float(tilt), float(zoom))
        finally:
            try:
                setattr(self.w, "_autotrack_driving", False)
            except Exception:
                pass
