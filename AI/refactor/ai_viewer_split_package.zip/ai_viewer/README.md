# ai_viewer split package

This is an automated split of `mdi_app.py` into modules:
- core: config, stream, tracking
- ai: detectors.yolo, recognition.face_db, recognition.pets_db
- ui: camera_widget, windows
- tools: dupes (from tools.py), gallery (from gallery.py)

Missing symbols (not found in source): {}
