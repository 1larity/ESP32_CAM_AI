# package
__all__ = ["YOLODetector"]
