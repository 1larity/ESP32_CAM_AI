WINDOW_SIZE = (1280, 720)
CONFIDENCE_THRESHOLD = 0.3
IGNORE_CLASSES = ['kangaroo']
PTZ_COMMANDS = ['up', 'down', 'left', 'right']
LAYOUT_FILE = 'layout.json'
