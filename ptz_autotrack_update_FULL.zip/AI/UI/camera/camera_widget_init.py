# camera/camera_widget_init.py
# Build UI, state and signal wiring for CameraWidget.

from __future__ import annotations
from PySide6 import QtCore, QtWidgets
from ..graphics_view import GraphicsView
from ..overlays import OverlayFlags


def init_camera_widget(self) -> None:
    """Build per-camera UI, backend helpers and signal wiring."""

    # Attach auto-track helpers (safe to call multiple times).
    from .camera_widget_autotrack import attach_autotrack_handlers
    attach_autotrack_handlers(self.__class__)


    # Heavy imports (cv2/CUDA) are deferred until the loader dialog is visible.
    from detectors import DetectorThread, DetectorConfig
    from recorder import PrebufferRecorder
    from presence import PresenceBus
    from stream import StreamCapture
    from enrollment import EnrollmentService
    from face_params import FaceParams

    # ------------------------------------------------------------------
    # Scene + view
    # ------------------------------------------------------------------
    self._scene = QtWidgets.QGraphicsScene(self)
    self._pixmap_item = QtWidgets.QGraphicsPixmapItem()
    self._scene.addItem(self._pixmap_item)
    self.view = GraphicsView(self._scene, self)
    # Needed for PTZ hotkeys (arrow keys / PgUp/PgDn) when the view is focused.
    self.view.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
    try:
        # Mouse events are delivered to the viewport widget in QGraphicsView.
        self.view.viewport().installEventFilter(self)
    except Exception:
        pass
    try:
        self.view.installEventFilter(self)
    except Exception:
        pass

    root_layout = QtWidgets.QVBoxLayout(self)
    root_layout.setContentsMargins(0, 0, 0, 0)

    # ------------------------------------------------------------------
    # Toolbar
    # ------------------------------------------------------------------
    tb = QtWidgets.QHBoxLayout()
    self.btn_rec = QtWidgets.QPushButton("REC")
    self.btn_snap = QtWidgets.QPushButton("Snapshot")
    # View menu (replaces Fit / 100% / Fit win buttons)
    self.btn_view_menu = QtWidgets.QToolButton()
    self.btn_view_menu.setText("View")
    self.btn_view_menu.setPopupMode(
        QtWidgets.QToolButton.ToolButtonPopupMode.InstantPopup
    )
    self.menu_view = QtWidgets.QMenu(self)

    # View scaling actions
    self.act_view_fit = self.menu_view.addAction("Fit in view")
    self.act_view_100 = self.menu_view.addAction("100% (1:1)")
    self.act_view_fit_window = self.menu_view.addAction("Fit window to video")
    self.menu_view.addSeparator()
    self.act_autotrack = self.menu_view.addAction("Auto-track (PTZ)")
    self.act_autotrack.setCheckable(True)
    self.act_autotrack.setChecked(bool(getattr(self.cam_cfg, "autotrack_enabled", False)))

    self.btn_view_menu.setMenu(self.menu_view)

    self.btn_info = QtWidgets.QToolButton()
    self.btn_info.setText("Info")
    self.btn_cam_settings = QtWidgets.QToolButton()
    self.btn_cam_settings.setText("Cam Settings")
    # Recording indicator (moved to overlay; keep label but do not show in toolbar)
    self.lbl_rec = QtWidgets.QLabel("")
    self.lbl_rec.setStyleSheet("color: red; font-weight: bold;")
    self.lbl_rec.setVisible(False)

    # Overlays menu (controls moved into Cam Settings dialog; keep actions for logic)
    self.btn_overlay_menu = QtWidgets.QToolButton()
    self.btn_overlay_menu.setVisible(False)
    self.menu_overlays = QtWidgets.QMenu(self)
    self.act_overlay_detections = self.menu_overlays.addAction(
        "Detections (boxes + labels)"
    )
    self.act_overlay_detections.setCheckable(True)
    self.act_overlay_detections.setChecked(True)
    self.act_overlay_hud = self.menu_overlays.addAction("HUD (cam + time)")
    self.act_overlay_hud.setCheckable(True)
    self.act_overlay_hud.setChecked(True)
    self.act_overlay_stats = self.menu_overlays.addAction("Stats (FPS + counts)")
    self.act_overlay_stats.setCheckable(True)
    self.act_overlay_stats.setChecked(True)
    self.btn_overlay_menu.setMenu(self.menu_overlays)

    # AI menu
    self.btn_ai_menu = QtWidgets.QToolButton()
    self.btn_ai_menu.setText("AI")
    self.btn_ai_menu.setPopupMode(
        QtWidgets.QToolButton.ToolButtonPopupMode.InstantPopup
    )
    self.btn_ai_menu.setVisible(False)  # moved into Cam Settings
    self.menu_ai = QtWidgets.QMenu(self)

    self.act_ai_enabled = self.menu_ai.addAction("Enable AI")
    self.act_ai_enabled.setCheckable(True)
    self.act_ai_enabled.setChecked(True)

    self.act_ai_yolo = self.menu_ai.addAction("YOLO")
    self.act_ai_yolo.setCheckable(True)
    self.act_ai_yolo.setChecked(True)

    self.act_ai_faces = self.menu_ai.addAction("Faces")
    self.act_ai_faces.setCheckable(True)
    self.act_ai_faces.setChecked(True)

    self.act_ai_pets = self.menu_ai.addAction("Pets")
    self.act_ai_pets.setCheckable(True)
    self.act_ai_pets.setChecked(True)

    self.btn_ai_menu.setMenu(self.menu_ai)

    # Assemble toolbar (same order as before, but with View menu)
    tb.addWidget(self.btn_rec)
    tb.addWidget(self.btn_snap)
    tb.addSpacing(12)
    tb.addWidget(self.btn_ai_menu)
    tb.addStretch(1)
    tb.addWidget(self.btn_view_menu)
    tb.addWidget(self.btn_info)
    tb.addWidget(self.btn_cam_settings)

    root_layout.addLayout(tb)
    root_layout.addWidget(self.view)

    # ------------------------------------------------------------------
    # State
    # Auto-track controller (PTZ moving-object tracking)
    try:
        from tracking import PtzAutoTracker
        self._autotrack = PtzAutoTracker(self)
    except Exception:
        self._autotrack = None
    self._autotrack_manual_until_ms = 0
    self._autotrack_driving = False

    # ------------------------------------------------------------------
    self._overlays = OverlayFlags()
    self._overlay_master_updating = False
    ai_enabled = getattr(self.cam_cfg, "ai_enabled", None)
    self._ai_enabled = True if ai_enabled is None else bool(ai_enabled)
    ai_yolo = getattr(self.cam_cfg, "ai_yolo", None)
    ai_faces = getattr(self.cam_cfg, "ai_faces", None)
    ai_pets = getattr(self.cam_cfg, "ai_pets", None)
    self._overlays.yolo = True if ai_yolo is None else bool(ai_yolo)
    self._overlays.faces = True if ai_faces is None else bool(ai_faces)
    self._overlays.pets = True if ai_pets is None else bool(ai_pets)

    self._last_bgr = None
    self._last_ts = 0
    self._last_pkt = None
    self._last_pkt_ts = 0
    self._last_bgr_for_motion = None
    self._auto_record_deadline = 0
    self._auto_recording_active = False
    self._rec_indicator_on = False
    # keep overlays around a bit to avoid flicker
    self._overlay_ttl_ms = 750  # matches previous CameraWidget
    # Enrollment service singleton
    self._enrollment = EnrollmentService.instance()
    # Prebuffer recorder: per-camera
    self._recorder = PrebufferRecorder(
        cam_name=self.cam_cfg.name,
        out_dir=self.app_cfg.output_dir,
        fps=25,
        pre_ms=self.app_cfg.prebuffer_ms,
    )

    # Presence logging bus (per camera)
    # Presence logging bus (per camera) with configurable grace period
    face_params = FaceParams.load(str(self.app_cfg.models_dir))
    self._show_face_box_size = bool(getattr(face_params, "show_box_size", False))
    self._mqtt_topic = (self.cam_cfg.name or "cam").replace(" ", "_")
    mqtt_publish = bool(getattr(self.cam_cfg, "mqtt_publish", True))
    self._presence = PresenceBus(
        self.cam_cfg.name,
        self.app_cfg.logs_dir,
        ttl_ms=getattr(face_params, "presence_ttl_ms", 6000),
        mqtt=self._mqtt if mqtt_publish else None,
        mqtt_topic=self._mqtt_topic,
    )
    # Configure unknown capture flags
    EnrollmentService.instance().set_unknown_capture(
        faces=getattr(self.app_cfg, "collect_unknown_faces", False),
        pets=getattr(self.app_cfg, "collect_unknown_pets", False),
        limit=getattr(self.app_cfg, "unknown_capture_limit", 50),
        min_interval_ms=getattr(self.app_cfg, "unknown_capture_min_interval_ms", 800),
        dupe_similarity_pct=getattr(
            self.app_cfg, "unknown_capture_dupe_similarity_pct", 95
        ),
        auto_train=getattr(self.app_cfg, "auto_train_unknowns", False),
    )

    # Detector thread – use app-level settings (as in original)
    det_cfg = DetectorConfig.from_app(self.app_cfg)
    self._detector = DetectorThread(det_cfg, self.cam_cfg.name)
    self._detector.resultsReady.connect(self._on_detections)

    # Stream capture backend
    self._capture = StreamCapture(self.cam_cfg)

    # Poll frames from StreamCapture for UI at a video-friendly cadence (~30 FPS)
    self._frame_timer = QtCore.QTimer(self)
    self._frame_timer.setInterval(33)  # 33 ms ≈ 30 FPS for smoother UI

    # MDI subwindow tracking
    self._subwindow = None

    # PTZ (ONVIF) overlay / hotkeys (populated lazily via discovery/capabilities).
    self._ptz_available = False
    self._ptz_has_zoom = False
    self._ptz_supports_presets = False
    self._ptz_hit_regions = {}
    self._ptz_mouse_action = None
    self._ptz_keys_down = set()
    self._ptz_active_vel = (0.0, 0.0, 0.0)
    self._ptz_device_xaddr = None
    self._ptz_xaddr = None
    self._ptz_profile_token = None
    self._ptz_detection_started = False
    self._ptz_repeat_timer = QtCore.QTimer(self)
    self._ptz_repeat_timer.setInterval(250)
    self._ptz_repeat_timer.timeout.connect(self._ptz_repeat_tick)

    # Apply persisted zoom level (view scale)
    try:
        init_scale = float(getattr(self.cam_cfg, "view_scale", 1.0) or 1.0)
    except Exception:
        init_scale = 1.0
    try:
        self.view._scale = init_scale
        self.view.resetTransform()
        self.view.scale(init_scale, init_scale)
    except Exception:
        pass

    # ------------------------------------------------------------------
    # Wiring
    # ------------------------------------------------------------------
    # Frame polling
    self._frame_timer.timeout.connect(self._poll_frame)

    # Recording / snapshot
    self.btn_rec.clicked.connect(self._toggle_recording)
    self.btn_snap.clicked.connect(self._snapshot)
    self.btn_cam_settings.clicked.connect(self._open_camera_settings)

    # View menu actions -> view helpers (provided by camera_widget_view.py)
    self.act_view_fit.triggered.connect(self.fit_to_window)
    self.act_view_100.triggered.connect(self.zoom_100)
    self.act_view_fit_window.triggered.connect(self.fit_window_to_video)

    # Auto-track toggle (PTZ)
    if hasattr(self, "act_autotrack"):
        try:
            self.act_autotrack.toggled.connect(self._on_autotrack_toggled)
        except Exception:
            pass

    self.btn_info.clicked.connect(self._show_info)
    try:
        self.view.zoomChanged.connect(self._on_zoom_changed)
    except Exception:
        pass

    # AI + overlay menu actions
    self.act_ai_enabled.toggled.connect(self._on_ai_toggled)
    self.act_ai_yolo.toggled.connect(self._on_ai_yolo_toggled)
    self.act_ai_faces.toggled.connect(self._on_ai_faces_toggled)
    self.act_ai_pets.toggled.connect(self._on_ai_pets_toggled)
    self.act_overlay_detections.toggled.connect(self._on_overlay_master_toggled)
    self.act_overlay_hud.toggled.connect(self._on_overlay_hud_toggled)
    self.act_overlay_stats.toggled.connect(self._on_overlay_stats_toggled)

    # Enrollment service – singleton
    self._enrollment = EnrollmentService.instance()

    # Defaults (respect per-camera overrides already applied)
    self.act_ai_enabled.setChecked(self._ai_enabled)
    self.act_ai_yolo.setChecked(self._overlays.yolo)
    self.act_ai_faces.setChecked(self._overlays.faces)
    self.act_ai_pets.setChecked(self._overlays.pets)
    self.act_overlay_detections.setChecked(
        self._overlays.yolo or self._overlays.faces or self._overlays.pets
    )
    self._overlays.hud = True
    self._overlays.stats = True

    # No flash controls (LED disabled)